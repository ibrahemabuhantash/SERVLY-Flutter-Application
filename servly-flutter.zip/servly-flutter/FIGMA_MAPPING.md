# Figma frame mapping

Primary implementation source: SERVLY bilingual frames (EN / ... and AR / ...). The 10 earlier concept frames are superseded by the expanded bilingual flows. One adaptive widget renders each locale rather than duplicating all 132 frames. System bars are native, not painted status bar decorations.

| Figma frame group | Flutter route / widget |
| --- | --- |
| Welcome | /welcome — WelcomeScreen |
| Login, Login error | /login — AuthScreen with actual field validation |
| Register | /register |
| OTP | /otp — demo code |
| Reset | /reset — simulated recovery |
| Home | /home |
| Services | /services |
| Search, Search empty | /search — filtered list / conditional empty |
| Detail 0–5 | /service/:id |
| Schedule 0–5 | /schedule/:id — actual date/time selection |
| Address 0–5, Address error | /address/:id — validation |
| Review 0–5 | /review/:id — parameterized draft |
| Confirmation 0–5 | /confirmation/:id — persisted booking |
| Bookings, Bookings empty | /bookings — conditional list/empty |
| Booking 0–5 | /booking/:id — persisted details |
| Cancel 0–5 | /cancel/:id |
| Cancelled | /cancelled |
| Notifications, Notifications empty | /notifications — event list/empty |
| Profile | /profile |
| Personal | /personal |
| Saved addresses | /addresses |
| New address | /address-new |
| Language | /language |
| Support | /support |
| Loading | /loading (preview; startup also loads local storage) |
| Error | /error (preview; actual error paths show retry or feedback) |

Service identifiers: cleaning, plumbing, electrical, ac, painting, handyman. The design's historical fixed date and single booking samples are dynamic in code. The localized theme uses native fallback fonts if Inter/Cairo aren't configured locally. Exact visual comparison and build still require device testing.
