import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:servly/main.dart';
import 'package:servly/domain/models.dart';
import 'package:servly/application/providers.dart';
class MemoryRepo implements DemoRepository{DemoState data=const DemoState();@override DemoState load()=>data;@override Future<void> save(DemoState state)async{data=state;}}
void main(){testWidgets('welcome, guest home and services', (tester)async{await tester.pumpWidget(ProviderScope(overrides:[repositoryProvider.overrideWithValue(MemoryRepo())],child:const ServlyApp()));await tester.pumpAndSettle();expect(find.text('Your home. In good hands.'),findsOneWidget);await tester.tap(find.text('Continue as guest'));await tester.pumpAndSettle();expect(find.text('What can we help you with today?'),findsOneWidget);await tester.tap(find.text('Services'));await tester.pumpAndSettle();expect(find.text('Explore services'),findsOneWidget);});}
