import 'package:flutter_test/flutter_test.dart';
import 'package:servly/domain/models.dart';
import 'package:servly/domain/booking_rules.dart';

void main(){
 final now=DateTime(2030,1,1,8),time=DateTime(2030,1,2,11);
 const address=ServiceAddress(name:'Demo User',phone:'0790000000',area:'Amman',street:'Sample street');
 BookingDraft draft({DateTime? at,String? id,String service='cleaning'})=>BookingDraft(service,appointment:at??time,address:address,editingId:id);
 Booking create()=>BookingRules.confirm(draft(),[],id:'SV-1',now:now);
 test('six services and original prices',(){expect(services.length,6);expect(services.map((s)=>s.priceFils),[15000,12000,18000,20000,25000,10000]);});
 test('Arabic and English search',(){expect(searchServices('السباكة').single.id,'plumbing');expect(searchServices('CLEAN').single.id,'cleaning');expect(searchServices('zzz'),isEmpty);});
 test('normalizes Jordan phone numbers',(){expect(validPhone('٠٧٩٠٠٠٠٠٠٠'),isTrue);expect(validPhone('+962790000000'),isTrue);expect(validPhone('123'),isFalse);});
 test('valid booking gets price from catalogue',(){final b=create();expect(b.priceFils,15000);expect(b.status,BookingStatus.confirmed);expect(b.appointment,time);});
 test('invalid draft rejected',(){expect(()=>BookingRules.confirm(const BookingDraft('cleaning'),[],id:'SV-1',now:now),throwsA(isA<BookingFailure>()));});
 test('past time and invalid slot rejected',(){expect(BookingRules.available(DateTime(2029),[],'cleaning',now:now),isFalse);expect(BookingRules.available(DateTime(2030,1,2,12),[],'cleaning',now:now),isFalse);});
 test('duplicate same service/time rejected but other service allowed',(){final b=create();expect(()=>BookingRules.confirm(draft(),[b],id:'SV-2',now:now),throwsA(isA<BookingFailure>()));expect(BookingRules.available(time,[b],'plumbing',now:now),isTrue);});
 test('reschedule retains reference and changes time',(){final b=create();final next=DateTime(2030,1,3,14);final changed=BookingRules.confirm(draft(at:next,id:b.id),[b],id:'unused',now:now);expect(changed.id,b.id);expect(changed.appointment,next);expect(changed.createdAt,b.createdAt);});
 test('cancel releases slot and cannot cancel twice',(){final b=BookingRules.cancel(create(),now:now);expect(b.status,BookingStatus.cancelled);expect(BookingRules.available(time,[b],'cleaning',now:now),isTrue);expect(()=>BookingRules.cancel(b,now:now),throwsA(isA<BookingFailure>()));});
 test('local state round trip preserves booking and locale',(){final b=create();final s=DemoState(language:'ar',started:true,bookings:[b]);final decoded=DemoState.fromJson(s.toJson());expect(decoded.language,'ar');expect(decoded.bookings.single.id,b.id);expect(decoded.bookings.single.address.street,address.street);});
}
