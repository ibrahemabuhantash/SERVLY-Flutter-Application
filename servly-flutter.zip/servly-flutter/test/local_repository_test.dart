import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:servly/data/local_repository.dart';
import 'package:servly/domain/models.dart';
void main(){TestWidgetsFlutterBinding.ensureInitialized();test('local storage save and restore',()async{SharedPreferences.setMockInitialValues({});final prefs=await SharedPreferences.getInstance();final repo=LocalDemoRepository(prefs);await repo.save(const DemoState(language:'ar',started:true));expect(LocalDemoRepository(prefs).load().language,'ar');expect(repo.load().started,isTrue);});test('invalid JSON falls back safely',()async{SharedPreferences.setMockInitialValues({LocalDemoRepository.key:'invalid'});final repo=LocalDemoRepository(await SharedPreferences.getInstance());expect(repo.load().bookings,isEmpty);});}
