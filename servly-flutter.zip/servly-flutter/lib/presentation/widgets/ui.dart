import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme.dart';
import '../../core/i18n.dart';
import '../../domain/models.dart';
class SIcon extends StatelessWidget {
  final String name; final double size;
  const SIcon(this.name,{this.size=24,super.key});
  @override Widget build(BuildContext context)=>SvgPicture.asset('assets/icons/$name.svg',width:size,height:size,excludeFromSemantics:true);
}
class Heading extends StatelessWidget {
  final String text; final double size;
  const Heading(this.text,{this.size=24,super.key});
  @override Widget build(BuildContext context)=>Text(text,style:TextStyle(fontSize:size,fontWeight:FontWeight.w700,color:Brand.ink));
}
Widget muted(String text,{double size=16})=>Text(text,style:TextStyle(fontSize:size,color:Brand.muted));
Widget gap([double h=16])=>SizedBox(height:h);
class Panel extends StatelessWidget {
  final Widget child; final Color color; final EdgeInsetsGeometry padding;
  const Panel({required this.child,this.color=Colors.white,this.padding=const EdgeInsets.all(16),super.key});
  @override Widget build(BuildContext context)=>Container(width:double.infinity,padding:padding,decoration:BoxDecoration(color:color,borderRadius:BorderRadius.circular(16),border:Border.all(color:Brand.line)),child:child);
}
class InfoPanel extends StatelessWidget {
  final String title,description;final Color color;
  const InfoPanel(this.title,this.description,{this.color=Colors.white,super.key});
  @override Widget build(BuildContext c)=>Panel(color:color,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Heading(title,size:18),gap(8),muted(description,size:14)]));
}
class Action extends StatelessWidget {
  final String text; final VoidCallback? onTap; final bool loading;
  const Action(this.text,this.onTap,{this.loading=false,super.key});
  @override Widget build(BuildContext context)=>SizedBox(width:double.infinity,child:FilledButton(onPressed:loading?null:onTap,child:loading?const SizedBox.square(dimension:22,child:CircularProgressIndicator(strokeWidth:2)):Text(text,textAlign:TextAlign.center)));
}
class LinkText extends StatelessWidget {
  final String text;final VoidCallback onTap;
  const LinkText(this.text,this.onTap,{super.key});
  @override Widget build(BuildContext c)=>Align(alignment:AlignmentDirectional.centerStart,child:TextButton(style:TextButton.styleFrom(padding:EdgeInsets.zero,minimumSize:const Size(48,48),foregroundColor:Brand.primary),onPressed:onTap,child:Text(text,style:const TextStyle(fontWeight:FontWeight.w700))));
}
class ServlyPage extends StatelessWidget {
  final String? title,back; final List<Widget> children; final Widget? bottom; final int? tab;
  const ServlyPage({this.title,this.back,required this.children,this.bottom,this.tab,super.key});
  @override Widget build(BuildContext c)=>Scaffold(resizeToAvoidBottomInset:true,body:SafeArea(bottom:tab==null,child:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:600),child:Column(children:[if(title!=null) Padding(padding:const EdgeInsets.fromLTRB(20,12,20,8),child:Row(children:[if(back!=null) ...[SizedBox.square(dimension:48,child:IconButton(style:IconButton.styleFrom(backgroundColor:Colors.white,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12))),tooltip:tr(c,'Back','رجوع'),onPressed:(){if(c.canPop()){c.pop();}else{c.go(back!);}},icon:SIcon(rtl(c)?'back_rtl':'back'))),const SizedBox(width:12)],Expanded(child:Heading(title!,size:24))])),Expanded(child:ListView(padding:const EdgeInsets.fromLTRB(24,16,24,24),children:children)),if(bottom!=null)Padding(padding:const EdgeInsets.fromLTRB(24,8,24,16),child:bottom!) ])))),bottomNavigationBar:tab==null?null:NavBar(tab!));
}
class NavBar extends StatelessWidget {
  final int index;const NavBar(this.index,{super.key});
  @override Widget build(BuildContext c){final titles=[tr(c,'Home','الرئيسية'),tr(c,'Services','الخدمات'),tr(c,'Bookings','الحجوزات'),tr(c,'Profile','حسابي')];final icons=['home','grid','calendar','user'];final paths=['/home','/services','/bookings','/profile'];return SafeArea(top:false,child:Material(color:Colors.white,child:Row(children:[for(var i=0;i<4;i++) Expanded(child:Semantics(selected:i==index,button:true,child:InkWell(onTap:()=>c.go(paths[i]),child:Container(color:i==index?Brand.soft:Colors.white,padding:const EdgeInsets.symmetric(vertical:12,horizontal:2),child:Column(mainAxisSize:MainAxisSize.min,children:[SIcon(icons[i]),gap(6),Text(titles[i],textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:i==index?Brand.primary:Brand.ink))])))))])));}
}
class ServiceCard extends StatelessWidget {
  final Service service;final VoidCallback? onTap;final String? detail,caption;
  const ServiceCard(this.service,{this.onTap,this.detail,this.caption,super.key});
  @override Widget build(BuildContext c)=>Material(color:Colors.white,borderRadius:BorderRadius.circular(16),child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(16),child:Panel(padding:const EdgeInsets.all(12),child:Row(children:[Container(width:60,height:60,decoration:BoxDecoration(color:Brand.soft,borderRadius:BorderRadius.circular(16)),alignment:Alignment.center,child:SIcon(service.icon)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Heading(service.title(rtl(c)),size:16),gap(3),muted(detail??tr(c,'Home service','خدمة منزلية'),size:13),gap(3),Text(caption??'${tr(c,'From','من')} ${price(c,service.priceFils)}',style:const TextStyle(fontSize:13,color:Brand.primary,fontWeight:FontWeight.bold))]))]))));
}
class Field extends StatelessWidget {
  final String label,hint;final TextEditingController controller;final String? Function(String?)? validator;final bool secret;final TextInputType? keyboard;
  const Field(this.label,this.hint,this.controller,{this.validator,this.secret=false,this.keyboard,super.key});
  @override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.only(bottom:12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:13)),gap(7),TextFormField(controller:controller,obscureText:secret,keyboardType:keyboard,autovalidateMode:AutovalidateMode.onUserInteraction,validator:validator,decoration:InputDecoration(hintText:hint,helperText:validator!=null?tr(c,'Required','مطلوب'):null),textInputAction:TextInputAction.next)]));
}
class StepLabel extends StatelessWidget{final int step;const StepLabel(this.step,{super.key});@override Widget build(BuildContext c)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(tr(c,'STEP $step OF 3','الخطوة $step من ٣'),style:const TextStyle(color:Brand.primary,fontWeight:FontWeight.bold,fontSize:12)),gap(8),Row(children:[for(var i=1;i<=3;i++)Expanded(child:Container(height:5,margin:const EdgeInsetsDirectional.only(end:6),decoration:BoxDecoration(color:i<=step?Brand.primary:Brand.line,borderRadius:BorderRadius.circular(3))))]),gap(20)]);}
void showFailure(BuildContext c,Object e)=>ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text(errorText(c,e))));
String? requiredText(BuildContext c,String? v)=>(v??'').trim().isEmpty?tr(c,'This field is required','هذا الحقل مطلوب'):null;
String? phoneError(BuildContext c,String? v)=>validPhone(v??'')?null:tr(c,'Enter a valid Jordanian mobile number','أدخل رقم هاتف أردني صحيح');
