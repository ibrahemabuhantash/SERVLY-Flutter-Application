import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../application/providers.dart';
import '../../domain/models.dart';
import '../../core/theme.dart';
import '../../core/i18n.dart';
import '../widgets/ui.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});
  @override Widget build(BuildContext c,WidgetRef ref){final unread=ref.watch(appProvider).notices.where((n)=>!n.read).length;return ServlyPage(tab:0,children:[Row(children:[Expanded(child:Heading(tr(c,'Amman, Jordan','عمّان، الأردن'),size:16)),TextButton(onPressed:()=>c.push('/notifications'),child:Text('${tr(c,'Alerts','الإشعارات')}${unread>0?' ($unread)':''}'))]),gap(14),Heading(tr(c,'What can we help you with today?','كيف يمكننا مساعدتك اليوم؟'),size:rtl(c)?24:28),gap(24),InkWell(onTap:()=>c.push('/search'),borderRadius:BorderRadius.circular(12),child:Panel(padding:const EdgeInsets.all(14),child:muted(tr(c,'Search for a service','ابحث عن خدمة'),size:14))),gap(16),Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Brand.dark,borderRadius:BorderRadius.circular(20)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(tr(c,'HOME CARE, MADE SIMPLE.','العناية بمنزلك بكل سهولة'),style:const TextStyle(fontSize:23,fontWeight:FontWeight.bold,color:Colors.white)),gap(12),Text(tr(c,'Book in minutes.','احجز خلال دقائق'),style:const TextStyle(fontSize:13,color:Brand.lime))])),gap(24),Heading(tr(c,'Categories','التصنيفات'),size:20),gap(12),LayoutBuilder(builder:(c,box){final columns=box.maxWidth<290?2:3;return GridView.count(crossAxisCount:columns,mainAxisSpacing:12,crossAxisSpacing:12,childAspectRatio:1.03,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),children:[for(final s in services) InkWell(onTap:()=>c.push('/service/${s.id}'),borderRadius:BorderRadius.circular(16),child:Panel(padding:const EdgeInsets.all(8),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[SIcon(s.icon),gap(8),Flexible(child:Text(s.title(rtl(c)),textAlign:TextAlign.center,style:const TextStyle(fontSize:12,fontWeight:FontWeight.bold)))])))]);}),gap(14),LinkText(tr(c,'Explore all services','استكشف كل الخدمات'),()=>c.go('/services'))]);}
}
class CatalogScreen extends StatefulWidget {
  final bool search;
  const CatalogScreen({this.search=false,super.key});
  @override State<CatalogScreen> createState()=>_CatalogScreenState();
}
class _CatalogScreenState extends State<CatalogScreen>{final query=TextEditingController();@override void dispose(){query.dispose();super.dispose();}
  @override Widget build(BuildContext c){final results=searchServices(query.text);return ServlyPage(title:widget.search?tr(c,'Search','البحث'):tr(c,'Explore services','استكشف الخدمات'),back:widget.search?'/services':null,tab:widget.search?null:1,children:[TextField(controller:query,autofocus:widget.search,onChanged:(_)=>setState((){}),decoration:InputDecoration(hintText:tr(c,'Search services','ابحث عن الخدمات'),prefixIcon:const Padding(padding:EdgeInsets.all(12),child:SIcon('search')),suffixIcon:query.text.isEmpty?null:IconButton(onPressed:(){query.clear();setState((){});},icon:const Icon(Icons.close)))),gap(16),if(results.isEmpty)...[gap(80),Heading(tr(c,'No matching services','لا توجد خدمات مطابقة')),gap(12),muted(tr(c,'Try another search or browse categories.','جرّب البحث بكلمات أخرى.')),gap(24),Action(tr(c,'Browse services','تصفح الخدمات'),(){query.clear();setState((){});})]else for(final s in results)...[ServiceCard(s,onTap:()=>c.push('/service/${s.id}')),gap(10)]]);}
}
class DetailScreen extends ConsumerWidget {
  final Service service;
  const DetailScreen(this.service,{super.key});
  @override Widget build(BuildContext c,WidgetRef ref)=>ServlyPage(title:tr(c,'Service details','تفاصيل الخدمة'),back:'/services',children:[Panel(color:Brand.soft,child:SizedBox(height:148,child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[SIcon(service.icon,size:68),gap(10),Text(service.title(rtl(c)),style:const TextStyle(color:Brand.primary,fontSize:19,fontWeight:FontWeight.bold))]))),gap(24),Heading(service.title(rtl(c)),size:28),gap(8),Text('${tr(c,'From','من')} ${price(c,service.priceFils)} ${tr(c,'/ visit','/ زيارة')}',style:const TextStyle(color:Brand.primary,fontSize:18,fontWeight:FontWeight.bold)),gap(12),Row(children:[const SIcon('clock'),const SizedBox(width:8),Expanded(child:muted(service.duration(rtl(c)),size:14))]),gap(24),Heading(tr(c,'What’s included','ماذا تشمل الخدمة؟'),size:20),gap(12),muted(tr(c,'On-site assessment, agreed service work and a final review.','تقييم في الموقع وتنفيذ العمل المتفق عليه ومراجعة نهائية.')),gap(28),InfoPanel(tr(c,'Transparent estimate','تكلفة تقديرية واضحة'),tr(c,'Final price depends on scope.','السعر النهائي يعتمد على نطاق العمل.'),color:Brand.soft)],bottom:Action(tr(c,'Book this service','احجز الخدمة'),(){ref.read(draftProvider.notifier).state=BookingDraft(service.id);c.push('/schedule/${service.id}');}));
}
