import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../application/providers.dart';
import '../../core/i18n.dart';
import '../../core/theme.dart';
import '../../domain/models.dart';
import '../widgets/ui.dart';

class WelcomeScreen extends ConsumerWidget {
  const WelcomeScreen({super.key});
  @override Widget build(BuildContext c,WidgetRef ref)=>ServlyPage(children:[gap(32),Container(height:270,padding:const EdgeInsets.all(24),decoration:BoxDecoration(color:Brand.dark,borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[const Text('servly.',style:TextStyle(fontSize:48,fontWeight:FontWeight.bold,color:Colors.white)),gap(12),Text(tr(c,'HOME SERVICES','الخدمات المنزلية'),style:const TextStyle(color:Brand.lime,fontSize:18,fontWeight:FontWeight.bold))])),gap(40),Heading(tr(c,'Your home. In good hands.','منزلك في أيدٍ أمينة'),size:35),gap(20),muted(tr(c,'Book home services in a few simple steps.','احجز خدمات منزلك بخطوات بسيطة.'),size:17),gap(20),muted(tr(c,'Portfolio demo. Use fictional details only.','مشروع تجريبي. استخدم بيانات افتراضية فقط.'),size:13)],bottom:Column(mainAxisSize:MainAxisSize.min,children:[Action(tr(c,'Get started','ابدأ الآن'),()=>c.push('/login')),LinkText(tr(c,'Continue as guest','المتابعة كضيف'),()async{try{await ref.read(appProvider.notifier).signIn();if(c.mounted)c.go('/home');}catch(e){if(c.mounted)showFailure(c,e);}}),LinkText(tr(c,'العربية','English'),()async{try{await ref.read(appProvider.notifier).language(rtl(c)?'en':'ar');}catch(e){if(c.mounted)showFailure(c,e);}})]));
}
class AuthScreen extends ConsumerStatefulWidget {
  final String mode;
  const AuthScreen(this.mode,{super.key});
  @override ConsumerState<AuthScreen> createState()=>_AuthScreenState();
}
class _AuthScreenState extends ConsumerState<AuthScreen> {
  final _form=GlobalKey<FormState>();final _name=TextEditingController(),_phone=TextEditingController(),_password=TextEditingController(),_code=TextEditingController();bool busy=false;
  @override void dispose(){_name.dispose();_phone.dispose();_password.dispose();_code.dispose();super.dispose();}
  Future<void> submit()async{
    if(busy||!(_form.currentState?.validate()??false))return;
    setState(()=>busy=true);
    try{
      if(widget.mode=='login'){await ref.read(appProvider.notifier).signIn(phone:_phone.text.trim());if(mounted)context.go('/home');}
      else if(widget.mode=='otp'){
        final reset=ref.read(authResetProvider);
        if(reset){ref.read(authResetProvider.notifier).state=false;if(mounted)context.go('/login');}
        else {await ref.read(appProvider.notifier).signIn(name:ref.read(authNameProvider),phone:ref.read(authPhoneProvider));if(mounted)context.go('/home');}
        ref.read(authPhoneProvider.notifier).state='';ref.read(authNameProvider.notifier).state='';
      }else{
        ref.read(authPhoneProvider.notifier).state=_phone.text.trim();ref.read(authNameProvider.notifier).state=_name.text.trim();ref.read(authResetProvider.notifier).state=widget.mode=='reset';if(mounted)context.push('/otp');
      }
    }catch(e){if(mounted)showFailure(context,e);}finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext c){final login=widget.mode=='login',register=widget.mode=='register',otp=widget.mode=='otp',reset=widget.mode=='reset';
    final title=login?tr(c,'Welcome back','أهلاً بعودتك'):register?tr(c,'Create account','إنشاء حساب'):otp?tr(c,'Verify phone','تحقق من الهاتف'):tr(c,'Reset password','استعادة كلمة المرور');
    return ServlyPage(title:title,back:login?'/welcome':'/login',children:[if(login)muted(tr(c,'Sign in to manage bookings','سجّل الدخول لإدارة حجوزاتك')),if(otp)muted(tr(c,'Enter the demo verification code: 123456.','أدخل رمز التحقق التجريبي: 123456.')),if(reset)muted(tr(c,'Enter your phone for demo recovery.','أدخل رقم هاتفك لمحاكاة الاستعادة.')),gap(32),Form(key:_form,child:Column(children:[if(register)Field(tr(c,'Full name','الاسم الكامل'),tr(c,'Enter name','أدخل الاسم'),_name,validator:(v)=>requiredText(c,v)),if(!otp)Field(tr(c,'Phone number','رقم الهاتف'),'07X XXX XXXX',_phone,keyboard:TextInputType.phone,validator:(v)=>phoneError(c,v)),if(login||register)Field(tr(c,'Password','كلمة المرور'),'••••••••',_password,secret:true,validator:(v)=>(v??'').length>=8?null:tr(c,'At least 8 characters','٨ أحرف على الأقل')),if(otp)Field(tr(c,'Verification code','رمز التحقق'),'123456',_code,keyboard:TextInputType.number,validator:(v)=>normalizeDigits(v??'').trim()=='123456'?null:tr(c,'Use demo code 123456','استخدم الرمز التجريبي 123456'))])),if(login)LinkText(tr(c,'Forgot password?','نسيت كلمة المرور؟'),()=>c.push('/reset')),gap(20),Action(login?tr(c,'Sign in (demo)','دخول تجريبي'):otp?tr(c,'Verify (demo)','تحقق تجريبي'):tr(c,'Continue','متابعة'),submit,loading:busy),if(login)...[gap(10),LinkText(tr(c,'Create account','إنشاء حساب'),()=>c.push('/register')),LinkText(tr(c,'Continue as guest','المتابعة كضيف'),()async{try{await ref.read(appProvider.notifier).signIn();if(c.mounted)c.go('/home');}catch(e){if(c.mounted)showFailure(c,e);}})],if(otp)LinkText(tr(c,'Show demo code again','إظهار الرمز التجريبي'),()=>ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('123456')))),gap(14),muted(tr(c,'Demo only. No real authentication, SMS or password reset. Do not use real credentials.','محاكاة فقط. لا يوجد تسجيل دخول أو رسائل أو استعادة حقيقية. لا تستخدم بيانات حقيقية.'),size:13)]);
  }
}
