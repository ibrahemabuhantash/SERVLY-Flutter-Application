class Service {
  final String id, en, ar, icon, durationEn, durationAr;
  final int priceFils;
  const Service(this.id, this.en, this.ar, this.icon, this.priceFils,
      this.durationEn, this.durationAr);
  String title(bool rtl) => rtl ? ar : en;
  String duration(bool rtl) => rtl ? durationAr : durationEn;
}

const services = <Service>[
  Service('cleaning', 'Cleaning', 'التنظيف', 'sparkles', 15000, '2–3 hours', '٢–٣ ساعات'),
  Service('plumbing', 'Plumbing', 'السباكة', 'wrench', 12000, '1–2 hours', '١–٢ ساعة'),
  Service('electrical', 'Electrical', 'الكهرباء', 'zap', 18000, '1–2 hours', '١–٢ ساعة'),
  Service('ac', 'AC repair', 'صيانة التكييف', 'wind', 20000, '1–2 hours', '١–٢ ساعة'),
  Service('painting', 'Painting', 'الدهان', 'paint', 25000, '3–4 hours', '٣–٤ ساعات'),
  Service('handyman', 'Handyman', 'الصيانة العامة', 'hammer', 10000, '1 hour', 'ساعة واحدة'),
];
Service? serviceById(String? id) {
  for (final s in services) { if (s.id == id) return s; }
  return null;
}
List<Service> searchServices(String query) {
  final q = query.trim().toLowerCase();
  return services.where((s) => '${s.en} ${s.ar} ${s.id}'.toLowerCase().contains(q)).toList();
}
String money(int fils) => (fils / 1000).toStringAsFixed(2);
String normalizeDigits(String value) {
  const arabic = '٠١٢٣٤٥٦٧٨٩'; const persian = '۰۱۲۳۴۵۶۷۸۹';
  for (var i=0;i<10;i++) { value=value.replaceAll(arabic[i], '$i').replaceAll(persian[i], '$i'); }
  return value;
}
bool validPhone(String input) => RegExp(r'^(?:07\d{8}|\+9627\d{8})$').hasMatch(normalizeDigits(input).replaceAll(RegExp(r'[\s-]'), ''));

class ServiceAddress {
  final String name, phone, area, street, notes;
  const ServiceAddress({required this.name, required this.phone, required this.area, required this.street, this.notes = ''});
  bool get isValid => name.trim().isNotEmpty && validPhone(phone) && area.trim().isNotEmpty && street.trim().isNotEmpty;
  String get summary => '$area • $street';
  Map<String, dynamic> toJson() => {'name':name,'phone':phone,'area':area,'street':street,'notes':notes};
  factory ServiceAddress.fromJson(Map<String,dynamic> j) => ServiceAddress(name:j['name'] as String,phone:j['phone'] as String,area:j['area'] as String,street:j['street'] as String,notes:j['notes'] as String? ?? '');
}
enum BookingStatus { confirmed, pending, completed, cancelled }
class Booking {
  final String id, serviceId;
  final DateTime appointment, createdAt;
  final ServiceAddress address;
  final int priceFils;
  final BookingStatus status;
  const Booking({required this.id,required this.serviceId,required this.appointment,required this.createdAt,required this.address,required this.priceFils,this.status=BookingStatus.confirmed});
  Booking copyWith({DateTime? appointment, BookingStatus? status}) => Booking(id:id,serviceId:serviceId,appointment:appointment??this.appointment,createdAt:createdAt,address:address,priceFils:priceFils,status:status??this.status);
  bool get active => status==BookingStatus.confirmed || status==BookingStatus.pending;
  Map<String,dynamic> toJson()=>{'id':id,'serviceId':serviceId,'appointment':appointment.toIso8601String(),'createdAt':createdAt.toIso8601String(),'address':address.toJson(),'priceFils':priceFils,'status':status.name};
  factory Booking.fromJson(Map<String,dynamic> j)=>Booking(id:j['id'] as String,serviceId:j['serviceId'] as String,appointment:DateTime.parse(j['appointment'] as String),createdAt:DateTime.parse(j['createdAt'] as String),address:ServiceAddress.fromJson(Map<String,dynamic>.from(j['address'] as Map)),priceFils:j['priceFils'] as int,status:BookingStatus.values.byName(j['status'] as String));
}
class BookingDraft {
  final String serviceId;
  final DateTime? appointment;
  final ServiceAddress? address;
  final String? editingId;
  const BookingDraft(this.serviceId,{this.appointment,this.address,this.editingId});
  BookingDraft withAppointment(DateTime value)=>BookingDraft(serviceId,appointment:value,address:address,editingId:editingId);
  BookingDraft withAddress(ServiceAddress value)=>BookingDraft(serviceId,appointment:appointment,address:value,editingId:editingId);
}
class Notice {
  final String id, bookingId, kind;
  final DateTime createdAt;
  final bool read;
  const Notice(this.id,this.bookingId,this.kind,this.createdAt,{this.read=false});
  Notice markRead()=>Notice(id,bookingId,kind,createdAt,read:true);
  Map<String,dynamic> toJson()=>{'id':id,'bookingId':bookingId,'kind':kind,'createdAt':createdAt.toIso8601String(),'read':read};
  factory Notice.fromJson(Map<String,dynamic> j)=>Notice(j['id'] as String,j['bookingId'] as String,j['kind'] as String,DateTime.parse(j['createdAt'] as String),read:j['read'] as bool? ?? false);
}
class DemoState {
  final String language, name, phone;
  final bool started;
  final List<Booking> bookings;
  final List<Notice> notices;
  final List<ServiceAddress> addresses;
  const DemoState({this.language='en',this.name='',this.phone='',this.started=false,this.bookings=const [],this.notices=const [],this.addresses=const []});
  DemoState copyWith({String? language,String? name,String? phone,bool? started,List<Booking>? bookings,List<Notice>? notices,List<ServiceAddress>? addresses})=>DemoState(language:language??this.language,name:name??this.name,phone:phone??this.phone,started:started??this.started,bookings:bookings??this.bookings,notices:notices??this.notices,addresses:addresses??this.addresses);
  Map<String,dynamic> toJson()=>{'language':language,'name':name,'phone':phone,'started':started,'bookings':bookings.map((b)=>b.toJson()).toList(),'notices':notices.map((n)=>n.toJson()).toList(),'addresses':addresses.map((a)=>a.toJson()).toList()};
  factory DemoState.fromJson(Map<String,dynamic> j){
    List<T> decode<T>(String k,T Function(Map<String,dynamic>) read) { final out=<T>[]; final raw=j[k]; if(raw is List){for(final v in raw){try{out.add(read(Map<String,dynamic>.from(v as Map)));}catch(_){}}} return List.unmodifiable(out); }
    return DemoState(language:j['language']=='ar'?'ar':'en',name:j['name'] is String?j['name'] as String:'',phone:j['phone'] is String?j['phone'] as String:'',started:j['started']==true,bookings:decode('bookings',Booking.fromJson).where((b)=>serviceById(b.serviceId)!=null).toList(growable:false),notices:decode('notices',Notice.fromJson),addresses:decode('addresses',ServiceAddress.fromJson));
  }
}
abstract interface class DemoRepository {
  DemoState load();
  Future<void> save(DemoState state);
}
