import 'dart:collection';
import 'models.dart';

class BookingFailure implements Exception {
  final String code;
  const BookingFailure(this.code);
  @override String toString()=>code;
}
class BookingRules {
  static const hours=[9,11,14,16];
  static bool sameSlot(DateTime a,DateTime b)=>a.year==b.year&&a.month==b.month&&a.day==b.day&&a.hour==b.hour&&a.minute==b.minute;
  static bool available(DateTime time,List<Booking> bookings,String serviceId,{String? exceptId,DateTime? now}) {
    final clock=now??DateTime.now();
    return time.isAfter(clock)&&hours.contains(time.hour)&&time.minute==0&&time.second==0&&time.millisecond==0&&time.microsecond==0&&!bookings.any((b)=>b.id!=exceptId&&b.active&&b.serviceId==serviceId&&sameSlot(b.appointment,time));
  }
  static Booking confirm(BookingDraft draft,List<Booking> bookings,{required String id,required DateTime now}) {
    final service=serviceById(draft.serviceId);
    final appointment=draft.appointment; final address=draft.address;
    if(service==null||appointment==null||address==null||!address.isValid)throw const BookingFailure('invalid');
    if(!available(appointment,bookings,service.id,exceptId:draft.editingId,now:now))throw const BookingFailure('unavailable');
    if(draft.editingId!=null){
      final old=bookings.where((b)=>b.id==draft.editingId&&b.active&&b.serviceId==service.id).firstOrNull;
      if(old==null||!old.appointment.isAfter(now))throw const BookingFailure('inactive');
      return Booking(id:old.id,serviceId:old.serviceId,appointment:appointment,createdAt:old.createdAt,address:address,priceFils:old.priceFils,status:old.status);
    }
    return Booking(id:id,serviceId:service.id,appointment:appointment,createdAt:now,address:address,priceFils:service.priceFils);
  }
  static Booking cancel(Booking booking,{DateTime? now}) {
    if(!booking.active||!booking.appointment.isAfter(now??DateTime.now()))throw const BookingFailure('inactive');
    return booking.copyWith(status:BookingStatus.cancelled);
  }
}
