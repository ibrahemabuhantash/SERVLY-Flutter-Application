import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'application/providers.dart';
import 'core/router.dart';
import 'core/theme.dart';
import 'data/local_repository.dart';

void main(){WidgetsFlutterBinding.ensureInitialized();runApp(const Bootstrap());}
class Bootstrap extends StatefulWidget{const Bootstrap({super.key});@override State<Bootstrap> createState()=>_BootstrapState();}
class _BootstrapState extends State<Bootstrap>{late Future<SharedPreferences> _prefs;@override void initState(){super.initState();_prefs=SharedPreferences.getInstance();}
@override Widget build(BuildContext context)=>FutureBuilder<SharedPreferences>(future:_prefs,builder:(c,s){if(s.hasData)return ProviderScope(overrides:[repositoryProvider.overrideWithValue(LocalDemoRepository(s.data!))],child:const ServlyApp());return MaterialApp(debugShowCheckedModeBanner:false,theme:Brand.theme(false),home:Scaffold(body:Center(child:s.hasError?Column(mainAxisSize:MainAxisSize.min,children:[const Text('Could not open local storage'),const SizedBox(height:16),FilledButton(onPressed:()=>setState(()=>_prefs=SharedPreferences.getInstance()),child:const Text('Retry'))]):const CircularProgressIndicator())));});}
class ServlyApp extends ConsumerWidget{const ServlyApp({super.key});@override Widget build(BuildContext c,WidgetRef ref){final language=ref.watch(appProvider.select((s)=>s.language));final router=ref.watch(routerProvider);return MaterialApp.router(title:'SERVLY',debugShowCheckedModeBanner:false,theme:Brand.theme(language=='ar'),locale:Locale(language),supportedLocales:const [Locale('en'),Locale('ar')],localizationsDelegates:GlobalMaterialLocalizations.delegates,routerConfig:router);}}
