import 'package:flutter/material.dart';
import '../domain/models.dart';
bool rtl(BuildContext c)=>Localizations.localeOf(c).languageCode=='ar';
String tr(BuildContext c,String en,String ar)=>rtl(c)?ar:en;
String price(BuildContext c,int fils)=>'${money(fils)} ${tr(c,'JD','د.أ')}';
String appointmentText(BuildContext c,DateTime d)=>'${MaterialLocalizations.of(c).formatMediumDate(d)} • ${MaterialLocalizations.of(c).formatTimeOfDay(TimeOfDay.fromDateTime(d))}';
String statusText(BuildContext c,BookingStatus s)=>switch(s){BookingStatus.confirmed=>tr(c,'Confirmed','مؤكد'),BookingStatus.pending=>tr(c,'Pending','قيد الانتظار'),BookingStatus.completed=>tr(c,'Completed','مكتمل'),BookingStatus.cancelled=>tr(c,'Cancelled','ملغى')};
String errorText(BuildContext c,Object e){final code=e.toString();return switch(code){'unavailable'=>tr(c,'This time is no longer available. Choose another time.','هذا الموعد لم يعد متاحاً. اختر موعداً آخر.'),'inactive'=>tr(c,'This booking can no longer be changed.','لا يمكن تعديل هذا الحجز.'),'invalid'=>tr(c,'Complete the booking details first.','أكمل بيانات الحجز أولاً.'),'busy'=>tr(c,'Please wait for the current action.','انتظر انتهاء العملية الحالية.'),_=>tr(c,'Could not save locally. Please try again.','تعذر الحفظ محلياً. حاول مرة أخرى.')};}
