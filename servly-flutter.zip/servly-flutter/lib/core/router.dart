import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../application/providers.dart';
import '../domain/models.dart';
import '../presentation/screens/auth.dart';
import '../presentation/screens/catalog.dart';
import '../presentation/screens/booking.dart';
import '../presentation/screens/profile.dart';
import '../presentation/widgets/ui.dart';
import 'i18n.dart';

final routerProvider=Provider<GoRouter>((ref){
  Widget byService(GoRouterState state,Widget Function(Service) build){final s=serviceById(state.pathParameters['id']);return s==null?const MissingFlow('/services'):build(s);}
  final router=GoRouter(initialLocation:ref.read(appProvider).started?'/home':'/welcome',routes:[
    GoRoute(path:'/welcome',builder:(c,s)=>const WelcomeScreen()),
    for(final mode in ['login','register','otp','reset'])GoRoute(path:'/$mode',builder:(c,s)=>AuthScreen(mode,key:ValueKey(mode))),
    GoRoute(path:'/home',builder:(c,s)=>const HomeScreen()),
    GoRoute(path:'/services',builder:(c,s)=>const CatalogScreen()),
    GoRoute(path:'/search',builder:(c,s)=>const CatalogScreen(search:true)),
    GoRoute(path:'/service/:id',builder:(c,s)=>byService(s,(v)=>DetailScreen(v,key:ValueKey(v.id)))),
    GoRoute(path:'/schedule/:id',builder:(c,s)=>byService(s,(v)=>ScheduleScreen(v,key:ValueKey(v.id)))),
    GoRoute(path:'/address/:id',builder:(c,s)=>byService(s,(v)=>AddressScreen(v,key:ValueKey(v.id)))),
    GoRoute(path:'/review/:id',builder:(c,s)=>byService(s,(v)=>ReviewScreen(v,key:ValueKey(v.id)))),
    GoRoute(path:'/confirmation/:id',builder:(c,s)=>ConfirmationScreen(s.pathParameters['id']!)),
    GoRoute(path:'/bookings',builder:(c,s)=>const BookingsScreen()),
    GoRoute(path:'/booking/:id',builder:(c,s)=>BookingDetailScreen(s.pathParameters['id']!)),
    GoRoute(path:'/cancel/:id',builder:(c,s)=>CancelScreen(s.pathParameters['id']!)),
    GoRoute(path:'/cancelled',builder:(c,s)=>const CancelledScreen()),
    GoRoute(path:'/notifications',builder:(c,s)=>const NotificationsScreen()),
    GoRoute(path:'/profile',builder:(c,s)=>const ProfileScreen()),
    GoRoute(path:'/personal',builder:(c,s)=>const PersonalScreen()),
    GoRoute(path:'/addresses',builder:(c,s)=>const AddressesScreen()),
    GoRoute(path:'/address-new',builder:(c,s)=>const NewAddressScreen()),
    GoRoute(path:'/language',builder:(c,s)=>const LanguageScreen()),
    GoRoute(path:'/support',builder:(c,s)=>const SupportScreen()),
    GoRoute(path:'/loading',builder:(c,s)=>const StateScreen(loading:true)),
    GoRoute(path:'/error',builder:(c,s)=>const StateScreen(loading:false)),
  ],errorBuilder:(c,s)=>ServlyPage(title:tr(c,'Page not found','الصفحة غير موجودة'),children:[Action(tr(c,'Home','الرئيسية'),()=>c.go('/home'))]));ref.onDispose(router.dispose);return router;
});
