import 'dart:collection';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/models.dart';
import '../domain/booking_rules.dart';

final repositoryProvider=Provider<DemoRepository>((ref)=>throw StateError('Repository not initialized'));
final appProvider=StateNotifierProvider<AppController,DemoState>((ref)=>AppController(ref.watch(repositoryProvider)));
final draftProvider=StateProvider<BookingDraft?>((ref)=>null);
final authPhoneProvider=StateProvider<String>((ref)=>'');
final authNameProvider=StateProvider<String>((ref)=>'');
final authResetProvider=StateProvider<bool>((ref)=>false);

class AppController extends StateNotifier<DemoState> {
  final DemoRepository repository;
  bool _busy=false;
  AppController(this.repository):super(repository.load());
  Future<T> _mutate<T>((DemoState,T) Function(DemoState) change) async {
    if(_busy)throw const BookingFailure('busy');
    _busy=true;
    try{final (next,result)=change(state);await repository.save(next);state=next;return result;}finally{_busy=false;}
  }
  Future<void> language(String lang)=>_mutate((s)=>(s.copyWith(language:lang=='ar'?'ar':'en'),null));
  Future<void> signIn({String name='',String phone=''})=>_mutate((s)=>(s.copyWith(started:true,name:name,phone:phone),null));
  Future<void> signOut()=>_mutate((s)=>(s.copyWith(started:false,name:'',phone:'',bookings:[],notices:[],addresses:[]),null));
  Future<void> profile(String name,String phone)=>_mutate((s)=>(s.copyWith(name:name.trim(),phone:phone.trim()),null));
  Future<void> addAddress(ServiceAddress address)=>_mutate((s)=>(s.copyWith(addresses:[...s.addresses,address]),null));
  Future<void> removeAddress(int index)=>_mutate((s)=>(s.copyWith(addresses:[for(var i=0;i<s.addresses.length;i++)if(i!=index)s.addresses[i]]),null));
  Future<void> clear()=>_mutate((s)=>(DemoState(language:s.language),null));
  String _id(DateTime now)=> 'SV-${now.microsecondsSinceEpoch}';
  Future<Booking> confirm(BookingDraft d)=>_mutate((s){
    final now=DateTime.now();final booking=BookingRules.confirm(d,s.bookings,id:_id(now),now:now);
    final list=d.editingId==null?[booking,...s.bookings]:[for(final b in s.bookings) if(b.id==booking.id) booking else b];
    return (s.copyWith(bookings:list,notices:[Notice('N-${now.microsecondsSinceEpoch}',booking.id,d.editingId==null?'confirmed':'rescheduled',now),...s.notices]),booking);
  });
  Future<void> cancel(String id)=>_mutate((s){
    final b=s.bookings.where((b)=>b.id==id).firstOrNull;if(b==null)throw const BookingFailure('inactive');
    final now=DateTime.now();final cancelled=BookingRules.cancel(b,now:now);
    return(s.copyWith(bookings:[for(final b in s.bookings)if(b.id==id)cancelled else b],notices:[Notice('N-${now.microsecondsSinceEpoch}',id,'cancelled',now),...s.notices]),null);
  });
  Future<void> readNotice(String id)=>_mutate((s)=>(s.copyWith(notices:[for(final n in s.notices)if(n.id==id)n.markRead()else n]),null));
  Future<void> readAll()=>_mutate((s)=>(s.copyWith(notices:s.notices.map((n)=>n.markRead()).toList()),null));
}
