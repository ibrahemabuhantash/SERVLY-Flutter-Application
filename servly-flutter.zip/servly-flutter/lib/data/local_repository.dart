import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../domain/models.dart';

class LocalDemoRepository implements DemoRepository {
  final SharedPreferences prefs;
  static const key='servly.demo.v1';
  const LocalDemoRepository(this.prefs);
  @override DemoState load(){
    final raw=prefs.getString(key);
    if(raw==null)return const DemoState();
    try{return DemoState.fromJson(Map<String,dynamic>.from(jsonDecode(raw) as Map));}catch(_){return const DemoState();}
  }
  @override Future<void> save(DemoState state) async {
    if(!await prefs.setString(key,jsonEncode(state.toJson())))throw StateError('Could not save local state');
  }
}
