#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v flutter >/dev/null || { echo 'Flutter SDK not found on PATH'; exit 1; }
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
flutter create --no-pub --platforms=android,ios --org com.servly --project-name servly "$tmp/servly"
for p in android ios; do
  if [ ! -d "$p" ] && [ -d "$tmp/servly/$p" ]; then cp -R "$tmp/servly/$p" .; fi
done
if [ ! -f .metadata ]; then cp "$tmp/servly/.metadata" .; fi
flutter pub get
