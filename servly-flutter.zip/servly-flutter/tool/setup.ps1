$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) { throw 'Flutter SDK missing. Install Flutter and add its bin directory to PATH.' }
$temp = Join-Path ([System.IO.Path]::GetTempPath()) ('servly_' + [guid]::NewGuid().ToString('N'))
try {
  flutter create --no-pub --platforms=android,ios --org com.servly --project-name servly $temp
  if ($LASTEXITCODE -ne 0) { throw 'Flutter platform scaffold creation failed.' }
  foreach ($platform in @('android','ios')) {
    if ((Test-Path (Join-Path $temp $platform)) -and -not (Test-Path $platform)) { Copy-Item (Join-Path $temp $platform) -Destination . -Recurse }
  }
  if (-not (Test-Path '.metadata')) { Copy-Item (Join-Path $temp '.metadata') -Destination . }
  flutter pub get
  if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
} finally { if (Test-Path $temp) { Remove-Item -Recurse -Force $temp } }
